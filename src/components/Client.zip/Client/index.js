
import React, {Component} from 'react';
import { compose } from 'recompose';

import { withFirebase } from '../../server/Firebase/index';
import { withAuthorization, withEmailVerification } from '../../server/Session/index';
import * as ROLES from '../../constants/roles';
import Client from './Client';
import FormContainer from './clientform';

class client extends React.Component {
  render(){
    return (
      <div>
        <Client/>
      </div>
    )

    
  };
}
/*
// condtion check for role
//  */
// const condition = authUser =>
//   authUser && authUser.roles.includes(ROLES.CLIENT);

// export default compose(
//   withEmailVerification,
//   withAuthorization(condition),
//   withFirebase,
// )(ClientPage);

export default client
